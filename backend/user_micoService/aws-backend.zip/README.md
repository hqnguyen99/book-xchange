for dev run "nodemon .",
to start "node ."

hosted on 3000, if you want to change port. Just change PORT variable in index.js
